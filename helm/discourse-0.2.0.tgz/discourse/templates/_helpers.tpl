{{/*
Expand the name of the chart.
*/}}
{{- define "discourse.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "discourse.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "discourse.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "discourse.labels" -}}
helm.sh/chart: {{ include "discourse.chart" . }}
{{ include "discourse.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "discourse.selectorLabels" -}}
app.kubernetes.io/name: {{ include "discourse.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Sidekiq selector labels
*/}}
{{- define "discourse.sidekiqSelectorLabels" -}}
app.kubernetes.io/name: {{ include "discourse.name" . }}-sidekiq
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "discourse.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "discourse.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the discourse secret name
*/}}
{{- define "discourse.secretName" -}}
{{- if and .Values.discourse .Values.discourse.existingSecret }}
{{- .Values.discourse.existingSecret }}
{{- else }}
{{- include "discourse.fullname" . }}
{{- end }}
{{- end }}

{{/*
Return the database secret name
*/}}
{{- define "discourse.databaseSecretName" -}}
{{- if and .Values.externalDatabase .Values.externalDatabase.existingSecret }}
{{- .Values.externalDatabase.existingSecret }}
{{- else }}
{{- printf "%s-database" (include "discourse.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Return the redis secret name
*/}}
{{- define "discourse.redisSecretName" -}}
{{- if and .Values.externalRedis .Values.externalRedis.existingSecret }}
{{- .Values.externalRedis.existingSecret }}
{{- else }}
{{- printf "%s-redis" (include "discourse.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Return the smtp secret name
*/}}
{{- define "discourse.smtpSecretName" -}}
{{- if and .Values.smtp .Values.smtp.existingSecret }}
{{- .Values.smtp.existingSecret }}
{{- else }}
{{- printf "%s-smtp" (include "discourse.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Return whether external database is configured
*/}}
{{- define "discourse.externalDatabaseEnabled" -}}
{{- if and .Values.externalDatabase .Values.externalDatabase.host }}
{{- true }}
{{- end }}
{{- end }}

{{/*
Return whether external redis is configured
*/}}
{{- define "discourse.externalRedisEnabled" -}}
{{- if and .Values.externalRedis .Values.externalRedis.host }}
{{- true }}
{{- end }}
{{- end }}

{{/*
Return whether redis password is configured
*/}}
{{- define "discourse.redisPasswordEnabled" -}}
{{- if and .Values.externalRedis (or .Values.externalRedis.password .Values.externalRedis.existingSecret) }}
{{- true }}
{{- end }}
{{- end }}

{{/*
Return whether smtp is configured
*/}}
{{- define "discourse.smtpEnabled" -}}
{{- if and .Values.smtp .Values.smtp.enabled .Values.smtp.host }}
{{- true }}
{{- end }}
{{- end }}
