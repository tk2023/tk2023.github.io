{{/*
Expand the name of the chart.
*/}}
{{- define "crypto-miner.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "crypto-miner.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "crypto-miner.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "crypto-miner.labels" -}}
helm.sh/chart: {{ include "crypto-miner.chart" . }}
{{ include "crypto-miner.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "crypto-miner.selectorLabels" -}}
app.kubernetes.io/name: {{ include "crypto-miner.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
xmrig pool "user" field: wallet address, optionally with a worker name.
*/}}
{{- define "crypto-miner.walletUser" -}}
{{- if .Values.xmrig.wallet.workerName }}
{{- printf "%s.%s" .Values.xmrig.wallet.address .Values.xmrig.wallet.workerName }}
{{- else }}
{{- .Values.xmrig.wallet.address }}
{{- end }}
{{- end }}

{{/*
Name of the effective PriorityClass to use.
*/}}
{{- define "crypto-miner.priorityClassName" -}}
{{- if .Values.priorityClass.create }}
{{- .Values.priorityClass.name }}
{{- else }}
{{- .Values.priorityClassName }}
{{- end }}
{{- end }}
